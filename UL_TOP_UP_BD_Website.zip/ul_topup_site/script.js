// SETUP: add your support WhatsApp number below in international format, digits only.
// Example Bangladesh number: 8801XXXXXXXXX (do not include + or spaces).
const SUPPORT_WHATSAPP = '';
const modal = document.getElementById('orderModal');
const packageSelect = document.getElementById('package');
const orderResult = document.getElementById('orderResult');
const orderText = document.getElementById('orderText');
function openOrder(pkg='') { modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); if(pkg) packageSelect.value=pkg; orderResult.hidden=true; document.body.style.overflow='hidden'; }
function closeOrder() { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); document.body.style.overflow=''; }
document.querySelectorAll('.order-btn').forEach(btn=>btn.addEventListener('click',()=>openOrder(btn.dataset.package)));
document.getElementById('closeModal').addEventListener('click',closeOrder);
modal.addEventListener('click',e=>{if(e.target===modal)closeOrder()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeOrder()});
document.getElementById('orderForm').addEventListener('submit',e=>{
 e.preventDefault();
 const pkg=packageSelect.value, uid=document.getElementById('uid').value.trim(), name=document.getElementById('customer').value.trim(), details=document.getElementById('details').value.trim();
 const msg=`UL TOP UP BD — অর্ডার\nপ্যাকেজ: ${pkg}\nPlayer UID: ${uid}\nনাম: ${name||'দেওয়া হয়নি'}\nবিস্তারিত: ${details||'দেওয়া হয়নি'}\n\nদয়া করে মূল্য ও পেমেন্ট নিশ্চিত করুন।`;
 orderText.value=msg; orderResult.hidden=false;
 if(SUPPORT_WHATSAPP){window.open(`https://wa.me/${SUPPORT_WHATSAPP}?text=${encodeURIComponent(msg)}`,'_blank','noopener');}
});
document.getElementById('copyOrder').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(orderText.value);document.getElementById('copyOrder').textContent='কপি হয়েছে ✓';}catch(e){orderText.select();document.execCommand('copy');document.getElementById('copyOrder').textContent='কপি হয়েছে ✓';}});
document.getElementById('contactBtn').addEventListener('click',()=>{if(SUPPORT_WHATSAPP){window.open(`https://wa.me/${SUPPORT_WHATSAPP}`,'_blank','noopener')}else{alert('প্রথমে script.js ফাইলে SUPPORT_WHATSAPP-এ আপনার WhatsApp নম্বর যোগ করুন।')}});
document.getElementById('menuBtn').addEventListener('click',()=>document.getElementById('nav').classList.toggle('show'));
document.querySelectorAll('#nav a').forEach(a=>a.addEventListener('click',()=>document.getElementById('nav').classList.remove('show')));
document.getElementById('year').textContent=new Date().getFullYear();
